"""Measure recorded work; correctness is supplied by a separate manual review."""
from collections import defaultdict
import datetime
import json
from pathlib import Path
import statistics

BASE = Path(__file__).resolve().parent
plan = json.loads((BASE / 'plan.json').read_text())
records = []
for pair in plan['pairs']:
    for run in pair['runs']:
        controller = Path(run['controller'])
        if not (controller / 'command-summary.json').exists():
            continue
        commands = json.loads((controller / 'command-summary.json').read_text())
        if not commands:
            continue
        status = json.loads((controller / 'status.json').read_text())
        first = min(datetime.datetime.fromisoformat(e['started_at']) for e in commands)
        last = max(datetime.datetime.fromisoformat(e['completed_at']) for e in commands)
        excluded = 0
        if 'setup_pause_started_at' in status:
            pause_start = datetime.datetime.fromisoformat(status['setup_pause_started_at'])
            pause_end = datetime.datetime.fromisoformat(status['setup_resumed_at'])
            excluded = max(0, (min(last, pause_end) - max(first, pause_start)).total_seconds())
        record = {'run_id': run['id'], 'pair': pair['pair'], 'arm': run['arm'],
            'recorded_commands': len(commands), 'first_command_at': first.isoformat(), 'last_command_at': last.isoformat(),
            'command_span_seconds_excluding_setup_pause': round((last-first).total_seconds() - excluded, 3),
            'time_to_artifact_seconds_excluding_setup_pause': round((last-datetime.datetime.fromisoformat(status['started_at'])).total_seconds() - excluded, 3),
            'summed_command_runtime_seconds': round(sum(e['elapsed_seconds'] for e in commands), 3),
            'excluded_setup_pause_seconds': excluded,
            'production_source_files': sorted({p for e in commands for p in e['production_files_in_after_patch']}),
            'agent_patch_matches_actual_tree': status.get('agent_patch_matches_actual_tree')}
        records.append(record)
by_arm = {}
for arm in ['off', 'on']:
    selected = [r for r in records if r['arm'] == arm]
    if selected:
        by_arm[arm] = {'n': len(selected),
            'median_time_to_artifact_seconds': statistics.median(r['time_to_artifact_seconds_excluding_setup_pause'] for r in selected),
            'total_time_to_artifact_seconds': sum(r['time_to_artifact_seconds_excluding_setup_pause'] for r in selected),
            'median_recorded_commands': statistics.median(r['recorded_commands'] for r in selected),
            'total_recorded_commands': sum(r['recorded_commands'] for r in selected)}
result = {'records': records, 'by_arm': by_arm,
    'limitations': 'Elapsed time is not token or dollar cost. Parallel compiler scheduling, shared dependency caches and the setup interruption affect timings. Commands may run concurrently, so summed command duration can exceed the wall span. Scope may differ between investigating and fixing.'}
(BASE / 'metrics.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(by_arm, indent=2))
