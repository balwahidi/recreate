"""Matched command and patch recording for six frozen pnpm agent runs."""
import datetime
import fcntl
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import time
import uuid

BASE = Path(__file__).resolve().parent.parent
args = sys.argv[1:]
if len(args) < 4 or args[0] != '--repo' or '--' not in args:
    raise SystemExit('Usage: record_command.py --repo REPO -- COMMAND [ARGS...]')
repo = Path(args[1]).resolve()
command = args[args.index('--') + 1:]
telemetry = repo.parent / '.telemetry'
telemetry.mkdir(exist_ok=True)
identifier = uuid.uuid4().hex

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def record(data):
    with (telemetry / 'commands.jsonl').open('a') as log:
        fcntl.flock(log, fcntl.LOCK_EX)
        log.write(json.dumps(data) + '\n')
        log.flush()
        fcntl.flock(log, fcntl.LOCK_UN)

def snapshot(suffix):
    output = subprocess.check_output(['git', '-C', str(repo), 'diff', 'HEAD', '--binary'], text=True)
    name = identifier + '.' + suffix + '.patch'
    (telemetry / name).write_text(output)
    return name

env = os.environ.copy()
env.update({
    'PATH': str(BASE / 'toolchain/cargo/bin') + ':' + env['PATH'],
    'RUSTUP_HOME': str(BASE / 'toolchain/rustup'),
    'CARGO_HOME': str(repo.parent / 'cache/cargo'),
    'CARGO_BUILD_JOBS': '4',
    'COREPACK_HOME': str(repo.parent / 'cache/corepack'),
    'XDG_CACHE_HOME': str(repo.parent / 'cache'),
    'XDG_DATA_HOME': str(repo.parent / 'cache/data'),
    'XDG_STATE_HOME': str(BASE / 'toolchain/state'),
    'npm_config_cache': str(repo.parent / 'cache/npm'),
    'pnpm_config_verify_deps_before_run': 'false',
    'PYTHONDONTWRITEBYTECODE': '1',
})
effective = list(command)
if len(command) >= 3 and command[0] == 'bash' and command[1] in ['-lc', '-c']:
    effective[2] = 'export PATH=' + shlex.quote(str(BASE / 'toolchain/cargo/bin')) + ':$PATH; ' + command[2]
start = time.monotonic()
record({'id': identifier, 'event': 'started', 'at': now(), 'command': command,
        'cwd': str(repo), 'before_patch': snapshot('before')})
with (telemetry / (identifier + '.output.log')).open('wb') as output:
    process = subprocess.Popen(effective, cwd=repo, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env, umask=0o022)
    while chunk := process.stdout.read1(16384):
        output.write(chunk)
        output.flush()
        sys.stdout.buffer.write(chunk)
        sys.stdout.buffer.flush()
    code = process.wait()
record({'id': identifier, 'event': 'completed', 'at': now(), 'command': command,
        'cwd': str(repo), 'exit_code': code, 'elapsed_seconds': round(time.monotonic() - start, 3),
        'after_patch': snapshot('after'), 'output_log': identifier + '.output.log'})
raise SystemExit(code if code >= 0 else 128 - code)
