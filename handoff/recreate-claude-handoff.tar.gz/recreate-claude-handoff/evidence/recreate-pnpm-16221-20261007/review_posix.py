"""Controller review of returned patches, not an additional evaluated-agent case.

Tests kernel shebang dispatch of the actual generated .ps1. A stand-in pwsh
prints a marker; this does not execute or emulate PowerShell or Windows.
"""
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

BASE = Path(__file__).resolve().parent
home = BASE / 'controller/posix-review'
repo = home / 'repo'
home.mkdir(exist_ok=True)
if not repo.exists():
    subprocess.run(['cp', '-a', '--reflink=auto', str(BASE / 'setup/repo'), str(repo)], check=True)
    (home / 'cache').mkdir()
    (home / 'cache/data').symlink_to(BASE / 'setup/cache/data', target_is_directory=True)
    subprocess.run(['cp', '-a', '--reflink=auto', str(BASE / 'setup/cache/corepack'), str(home / 'cache/corepack')], check=True)
env = os.environ.copy()
env.update(PATH=str(BASE / 'toolchain/cargo/bin') + ':' + env['PATH'],
    RUSTUP_HOME=str(BASE / 'toolchain/rustup'), CARGO_HOME=str(home / 'cache/cargo'),
    COREPACK_HOME=str(home / 'cache/corepack'), XDG_CACHE_HOME=str(home / 'cache'),
    XDG_DATA_HOME=str(home / 'cache/data'), pnpm_config_verify_deps_before_run='false')
case = json.loads((BASE / 'protocol/case.json').read_text())
variants = [('baseline', '') , ('upstream-fix', (BASE / 'controller/upstream-production.patch').read_text())]
plan = json.loads((BASE / 'plan.json').read_text())
for pair in plan['pairs']:
    run = next(r for r in pair['runs'] if r['arm'] == 'off')
    artifact = Path(run['workspace']) / 'agent-result.json'
    variants.append((run['id'], json.loads(artifact.read_text())['patch']))
records = []
for label, patch in variants:
    subprocess.run(['git', 'checkout', '-q', '-f', case['checkout']], cwd=repo, check=True)
    subprocess.run(['git', 'clean', '-ffdq'], cwd=repo, check=True)
    if patch:
        subprocess.run(['git', 'apply', '--whitespace=nowarn', '-'], input=patch, text=True, cwd=repo, check=True)
    build = subprocess.run(['corepack', 'pnpm', 'exec', 'tsgo', '--build', '--force', 'pnpm11/bins/cmd-shim'], cwd=repo, env=env, capture_output=True, text=True)
    (home / (label + '.build.log')).write_text(build.stdout + build.stderr)
    assert build.returncode == 0
    with tempfile.TemporaryDirectory(prefix='dispatch-', dir=home) as temp:
        fixture = Path(temp)
        target = fixture / '工具/cli.js'
        target.parent.mkdir()
        target.write_text('#!/usr/bin/env node\nconsole.log("CJKTOOL OK")\n')
        bin_dir = fixture / 'bin'
        bin_dir.mkdir()
        standin = bin_dir / 'pwsh'
        standin.write_text('#!/bin/sh\nprintf "PWSH_DISPATCH_OK\\n"\n')
        standin.chmod(0o755)
        shim = fixture / 'cjktool'
        script = 'import {cmdShim} from ' + json.dumps((repo / 'pnpm11/bins/cmd-shim/lib/index.js').as_uri()) + '; await cmdShim(' + json.dumps(str(target)) + ',' + json.dumps(str(shim)) + ',{createPwshFile:true});'
        subprocess.run(['node', '--input-type=module', '-e', script], cwd=repo, env=env, check=True)
        ps1 = Path(str(shim) + '.ps1')
        ps1.chmod(0o755)
        run_env = dict(env, PATH=str(bin_dir) + ':' + env['PATH'])
        record = {'variant': label, 'ps1_prefix_hex': ps1.read_bytes()[:3].hex()}
        try:
            observed = subprocess.run([str(ps1)], env=run_env, capture_output=True, text=True, timeout=10)
            record.update(exit_code=observed.returncode, stdout=observed.stdout.strip(), stderr=observed.stderr.strip(),
                          dispatched_to_interpreter=observed.returncode == 0 and observed.stdout.strip() == 'PWSH_DISPATCH_OK')
        except OSError as error:
            record.update(errno=error.errno, error=error.strerror, dispatched_to_interpreter=False)
        records.append(record)
        print(json.dumps(record), flush=True)
subprocess.run(['git', 'checkout', '-q', '-f', case['checkout']], cwd=repo, check=True)
subprocess.run(['git', 'clean', '-ffdq'], cwd=repo, check=True)
(home / 'results.json').write_text(json.dumps({'scope':'Linux kernel shebang dispatch only, using real generated shim and a stand-in pwsh interpreter. Not Windows or PowerShell execution.', 'records':records}, indent=2) + '\n')
