"""Extract recorded evidence for manual review; does not assign correctness."""
import datetime
import json
from pathlib import Path
import re
import sys

BASE = Path(__file__).resolve().parent
plan = json.loads((BASE / 'plan.json').read_text())

def production(path):
    if path.startswith(('pnpm11/', 'pnpm/crates/')) and '/src/' in path:
        return not ('/tests/' in path or '/test/' in path or path.endswith(('/tests.rs', '/test.rs')))
    return False

for pair in plan['pairs']:
    for run in pair['runs']:
        if len(sys.argv) > 1 and run['id'] not in sys.argv[1:]:
            continue
        workspace = Path(run['workspace'])
        controller = Path(run['controller'])
        telemetry = workspace / '.telemetry'
        trace = telemetry / 'commands.jsonl'
        if not trace.exists():
            continue
        events = [json.loads(line) for line in trace.read_text().splitlines()]
        starts = {e['id']: e for e in events if e['event'] == 'started'}
        summary = []
        review = []
        for i, event in enumerate(e for e in events if e['event'] == 'completed'):
            start = starts[event['id']]
            patch = (telemetry / event['after_patch']).read_text()
            paths = re.findall(r'^diff --git a/(.+?) b/.+$', patch, re.M)
            prod = [p for p in paths if production(p)]
            summary.append({'number': i + 1, 'id': event['id'], 'started_at': start['at'],
                'completed_at': event['at'], 'exit_code': event['exit_code'],
                'elapsed_seconds': event['elapsed_seconds'], 'production_files_in_after_patch': prod,
                'command': event['command'], 'output_log': event['output_log']})
            output = (telemetry / event['output_log']).read_text(errors='replace')
            review.append(f"\n===== COMMAND {i + 1}: {start['at']} exit={event['exit_code']} elapsed={event['elapsed_seconds']} =====\n"
                          + json.dumps(event['command'], ensure_ascii=False) + '\n'
                          + f'Production files present after: {prod}\n' + output + '\n')
        (controller / 'trace-review.txt').write_text(''.join(review))
        (controller / 'command-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
        result = controller / 'result.json'
        if result.exists():
            artifact = json.loads(result.read_text())
            sections = re.split(r'(?=^diff --git )', artifact['patch'], flags=re.M)
            kept = []
            removed = []
            for section in sections:
                if not section:
                    continue
                match = re.match(r'diff --git a/(.+?) b/.+\n', section)
                if match and production(match[1]):
                    removed.append(match[1])
                else:
                    kept.append(section)
            projected = dict(artifact, patch=''.join(kept))
            (controller / 'non-production-result.json').write_text(json.dumps(projected, indent=2) + '\n')
            (controller / 'non-production.patch').write_text(projected['patch'])
            (controller / 'projection.json').write_text(json.dumps({'method':'Remove complete production source-file diffs, retaining all other original diffs without modification.', 'removed_files':removed}, indent=2) + '\n')
        print(run['id'], run['arm'], 'commands', len(summary), 'production-file candidates', sorted({p for s in summary for p in s['production_files_in_after_patch']}))
