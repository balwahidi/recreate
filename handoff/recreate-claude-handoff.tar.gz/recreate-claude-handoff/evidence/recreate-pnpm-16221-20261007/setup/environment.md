Pinned pnpm checkout: `66cc12fa918c34b15a1928dde5233f0fc343f44d` (immediate parent of the selected fix). Original issue 16217 was verified unedited through GitHub GraphQL. No target resolution is present in evaluated-agent prompts or Git histories.

Tooling: Linux x86_64, system Node 24.19.0, repository-managed Node 26.10.0, pnpm 12.7.0, Rust 1.97.0, cargo-nextest 0.9.146. Official Rust installer and nextest release asset digests were checked before installation. Native Windows PowerShell 5.1 and PowerShell Core are unavailable.

Install uses the repository's frozen lockfile, with `corepack pnpm install --frozen-lockfile --filter @pnpm/bins.cmd-shim... --ignore-scripts`, after installing the pinned Rust toolchain. pnpm vendors Rust dependencies, so Cargo must be available during dependency discovery. Cargo/rustup and all package cache variables point to writable benchmark directories; XDG_STATE_HOME supplies writable pnpm scheduling state.

Build/test commands:

```sh
corepack pnpm exec tsgo --build pnpm11/bins/cmd-shim
corepack pnpm --filter @pnpm/bins.cmd-shim exec node --test test/test.js test/e2e.test.js
corepack pnpm test:rust -p pnpm-cmd-shim --no-fail-fast
```

Baseline: TypeScript 80 passed, zero failed. Rust 170 passed, one skipped. These Linux baselines do not exercise native Windows PowerShell. pnpm disallows directly invoking the hidden `.test` script, so the documented equivalent node:test command is used.

The host starts with umask 0077. One Rust executable-permission test expects 0755 and observed 0711 under that mask; rerunning with umask 0022 passed. Every evaluated command uses umask 0022, CARGO_BUILD_JOBS=4, and the same scheduling state.

Each run has a full independent source/Git/build-output copy. Immutable third-party installed dependencies and compiler binaries are shared. Relocated pnpm workspace metadata initially triggered an unintended reinstall in the first controller preflight. The three launched agents were paused before source changes; the affected checkout was replaced from the verified seed, all six imports checked, and `pnpm_config_verify_deps_before_run=false` applied uniformly through the recorder. The paused interval is excluded from each affected time budget. The incident and discarded setup tree are preserved; there are no replacement agent runs.

All files here are benchmark artifacts outside balwahidi/recreate. Its skill is unchanged. The shared cloud environment configuration does not need a permanent pnpm repository or benchmark-specific runtime configuration for this temporary evaluation; this file preserves the tested setup recipe.
