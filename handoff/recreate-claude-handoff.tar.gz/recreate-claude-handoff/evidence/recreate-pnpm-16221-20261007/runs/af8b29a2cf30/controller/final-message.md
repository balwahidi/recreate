**Status: Reproduced (simulated Windows PowerShell 5.1 ANSI decoding).**

Both current TypeScript and Rust shim generators produce BOM-less UTF-8. Simulating Windows-1252 script decoding changes 工具 to å·¥å…·; invoking Node with the resulting target exits 1 with MODULE_NOT_FOUND, instead of printing CJKTOOL OK.

UTF-8 decoding and adding a UTF-8 BOM both restore the expected output. The generated sh shim also works. The trigger is a non-ASCII literal in a BOM-less shim decoded with a legacy ANSI encoding; console code page 437 is separate.

Run from the repository root:
    corepack pnpm exec tsgo --build pnpm11/bins/cmd-shim && node repro/powershell-encoding.mjs

Artifacts: repro/README.md, repro/powershell-encoding.mjs, and the intentionally failing Rust integration test in pnpm/crates/cmd-shim/tests/powershell_encoding_repro.rs. The README includes its run command.

Validation: TypeScript build succeeded; existing shim tests reported 80 passed, 0 failed. Both new reproductions failed on the expected behavior. Native Windows/PowerShell execution and exact Node 24.16.0 remain unverified. No production code was changed.
