Confirmed and fixed in both pnpm v11 and v12: PowerShell shims containing non-ASCII characters now start with a UTF-8 BOM, so Windows PowerShell 5.1 decodes their paths correctly. ASCII-only shims retain their existing content. Added matching encoding tests, Windows execution regressions, and a changeset.

Validation: TypeScript build passed; 87 TypeScript shim tests and 171 Rust cmd-shim tests passed. New encoding regressions failed before the fix. Windows execution tests could not run on Linux. ESLint was blocked by the prepared environment's missing @eslint/js dependency.
