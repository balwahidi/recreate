Fixed the missing UTF-8 BOM in PowerShell shims for both pnpm implementations. Added Unicode-path regression tests and Windows PowerShell execution tests covering arguments and exit codes.

Validation: TypeScript build succeeded; 84 TypeScript tests and 171 Rust tests passed. Windows execution tests could not run on Linux. ESLint was blocked by missing @eslint/js; rustfmt was unavailable.
