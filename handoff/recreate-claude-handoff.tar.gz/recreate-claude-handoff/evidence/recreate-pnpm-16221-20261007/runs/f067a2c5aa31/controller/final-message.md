**Status: Reproduced (simulated Windows PowerShell 5.1 ANSI decoding).**

The reporter's fixture installs with pnpm 12.7.0. The current revision's TypeScript shim has no BOM; simulated Windows-1252 decoding changes `工具` to `å·¥å…·`, producing `MODULE_NOT_FOUND` and exit 1 instead of `CJKTOOL OK`. UTF-8 and BOM controls both pass.

Run: `corepack pnpm exec tsgo --build pnpm11/bins/cmd-shim && node reproductions/powershell51-unicode.mjs`. It deliberately fails the expected-behavior assertion.

Artifacts: `reproductions/powershell51-unicode.mjs` and its accompanying Markdown report. The build passed; existing cmd-shim tests passed (80 tests). Windows-only suites were skipped.

Native PowerShell was unavailable. Rust source has the same BOM omission, but was not executed. No production code was changed.
