Status: Reproduced (simulated Windows PowerShell 5.1 ANSI decoding).

Both current TypeScript and Rust shim generators emit UTF-8 without a BOM. With CP1252 decoding, the reported 工具 path becomes å·¥å…· and real Node exits 1 with MODULE_NOT_FOUND instead of printing CJKTOOL OK. UTF-8 decoding, a BOM-prefixed shim, and the installed shell shim all passed.

Run from the repository root:
corepack pnpm exec tsgo --build pnpm11/bins/cmd-shim && node pnpm11/bins/cmd-shim/repro/powershell-encoding.mjs --simulate

The reproducer intentionally exits 1. Artifacts: pnpm11/bins/cmd-shim/repro/ and pnpm/crates/cmd-shim/examples/reproduce_ps1_encoding.rs.

Windows PowerShell is unavailable here; this models its decoding and target argument, not its interpreter. CP1252 matches the reported mojibake; console code page 437 does not establish the Windows ANSI code page.

Validation: TypeScript build passed; existing suites passed 80 TypeScript tests and 170 Rust tests (one Rust test skipped). No production code changed.
