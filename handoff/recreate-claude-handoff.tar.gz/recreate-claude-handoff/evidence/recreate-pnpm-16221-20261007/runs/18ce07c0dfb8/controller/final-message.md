Fixed the bug in both TypeScript and Rust shim generators. PowerShell scripts containing non-ASCII text now receive a UTF-8 BOM; ASCII scripts remain unchanged. Added encoding regressions, Windows PowerShell 5.1 execution tests, and a changeset.

Verified that the new regressions fail before the fix. After the fix, the TypeScript build and all 86 focused tests pass; all 172 runnable Rust shim tests pass. Windows execution tests could not run on Linux. ESLint is blocked by missing @eslint/js, and the Rust formatter is not installed.
