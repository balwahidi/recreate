import datetime
import json
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent
plan = json.loads((BASE / 'plan.json').read_text())
pair = next(p for p in plan['pairs'] if p['pair'] == int(sys.argv[1]))
run = pair['runs'][int(sys.argv[2]) - 1]
agent = '/root/' + sys.argv[3]
path = Path(run['controller']) / 'status.json'
if path.exists():
    raise SystemExit('This run is already registered; no automatic replacement.')
status = {'run_id': run['id'], 'case': pair['case'], 'task': pair['task'], 'arm': run['arm'], 'pair':pair['pair'], 'repeat':pair['repeat'], 'agent':agent, 'state':'running', 'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'time_limit_seconds':pair['budget_seconds'], 'fresh_context':True, 'parent_turns_inherited':False}
path.write_text(json.dumps(status, indent=2) + '\n')
print(json.dumps({'run_id':run['id'], 'task_file':str(Path(run['workspace']) / 'task.txt'), 'agent':agent, 'budget_seconds':pair['budget_seconds']}))
