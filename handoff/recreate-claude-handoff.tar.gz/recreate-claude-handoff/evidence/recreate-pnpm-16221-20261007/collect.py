import datetime
import json
import os
import pathlib
import shutil
import subprocess
import sys

BASE = pathlib.Path("/workspace/recreate-pnpm-16221-20261007")
plan = json.loads((BASE / "plan.json").read_text())
run_id = sys.argv[1]
pair, run = next((pair, run) for pair in plan["pairs"] for run in pair["runs"] if run["id"] == run_id)
controller = pathlib.Path(run["controller"])
workspace = pathlib.Path(run["workspace"])
repo = workspace / "repo"
status = json.loads((controller / "status.json").read_text())
status.update(state="completed", ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
artifact = workspace / "agent-result.json"
if artifact.exists():
    result = json.loads(artifact.read_text())
    assert all(isinstance(result.get(k), str) for k in ["final_message","patch","run_command"])
    shutil.copy2(artifact, controller / "result.json")
    status["structured_result_valid"] = True
    (controller / "agent.patch").write_text(result["patch"])
    (controller / "run-command.txt").write_text(result["run_command"] + "\n")
    (controller / "final-message.md").write_text(result["final_message"] + "\n")
else:
    status["structured_result_valid"] = False
    status["artifact_error"] = "Agent completed without required agent-result.json"
index = controller / "capture.index"
shutil.copy2(repo / ".git/index", index)
env = os.environ.copy()
env["GIT_INDEX_FILE"] = str(index)
subprocess.run(["git","-C",str(repo),"add","-A"],env=env,check=True)
diff = subprocess.check_output(["git","-C",str(repo),"diff","--cached","--binary","HEAD"],env=env,text=True)
(controller / "actual-final.patch").write_text(diff)
if artifact.exists():
    status["agent_patch_matches_actual_tree"] = result["patch"].rstrip() == diff.rstrip()
    status["final_patch_bytes"] = len(result["patch"].encode())
commands = workspace / ".telemetry/commands.jsonl"
status["recorded_command_events"] = len(commands.read_text().splitlines()) if commands.exists() else 0
(controller / "status.json").write_text(json.dumps(status, indent=2) + "\n")
print(json.dumps(status, indent=2))

