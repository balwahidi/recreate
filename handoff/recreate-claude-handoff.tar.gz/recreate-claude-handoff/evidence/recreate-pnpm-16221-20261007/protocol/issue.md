# PowerShell command shims fail in Windows PowerShell 5.1 when the tool's path contains non-ASCII characters

Reported on 2026-09-26T20:54:06Z

### Verify latest release

- [x] I verified that the issue exists in the latest pnpm release

### pnpm version

12.7.0 and 11.28.0. Current `main` has it too: pnpm/pnpm#16205 fixed the same problem for `.cmd` shims, and the `.ps1` shims were not part of that change.

### Which area(s) of pnpm are affected? (leave empty if unsure)

CLI, Operating System (Windows, MacOS, Linux)

### Link to the code that reproduces this issue or a replay of the bug

_No response_

### Reproduction steps

1. Create a package whose bin path contains non-ASCII characters, and a project that depends on it:

   `cjk-tool/package.json`:
   ```json
   { "name": "cjk-tool", "version": "1.0.0", "bin": { "cjktool": "工具/cli.js" } }
   ```
   `cjk-tool/工具/cli.js`:
   ```js
   #!/usr/bin/env node
   console.log("CJKTOOL OK")
   ```
   `proj/package.json`:
   ```json
   { "name": "proj", "private": true, "dependencies": { "cjk-tool": "file:../cjk-tool" } }
   ```
2. Run `pnpm install` in `proj`.
3. In Windows PowerShell 5.1 (`powershell.exe`), run `.\node_modules\.bin\cjktool` in `proj`.

### Describe the Bug

The command fails, and PowerShell reports exit code 1:

```text
Error: Cannot find module 'C:\...\proj\node_modules\cjk-tool\å·¥å…·\cli.js'
  code: 'MODULE_NOT_FOUND',
```

Windows PowerShell 5.1 decodes a `.ps1` file that has no byte order mark using the ANSI code page. pnpm writes `cjktool.ps1` as UTF-8 without a BOM, so `工具` in the shim reaches Node.js as `å·¥å…·`.

The same shim runs correctly in PowerShell 7, and the `sh` shim runs correctly in Git Bash. Adding a UTF-8 BOM to the start of `cjktool.ps1` makes it run correctly in Windows PowerShell 5.1 too.

### Expected Behavior

The command runs and prints `CJKTOOL OK`, as it does in PowerShell 7.

### Which Node.js version are you using?

24.16.0

### Which operating systems have you used?

- [ ] macOS
- [x] Windows
- [ ] Linux

### If your OS is a Linux based, which one it is? (Include the version if relevant)

Windows 11 Pro, build 26200, active code page 437.

---
Written by an agent (Claude Code, claude-opus-5-5).

