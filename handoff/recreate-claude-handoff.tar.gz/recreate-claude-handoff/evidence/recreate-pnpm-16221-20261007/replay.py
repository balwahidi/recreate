"""Use the frozen repository grader; add environment/build support for pnpm 16217."""
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

BASE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('grade', BASE / 'protocol/evals/grade.py')
grade = importlib.util.module_from_spec(spec)
spec.loader.exec_module(grade)
case = json.loads((BASE / 'protocol/case.json').read_text())
grade.GRADE = BASE / 'controller/grade-work'
home = grade.GRADE / case['id']
repo = home / 'repo'
home.mkdir(parents=True, exist_ok=True)
if not repo.exists():
    subprocess.run(['cp', '-a', '--reflink=auto', str(BASE / 'setup/repo'), str(repo)], check=True)
    cache = home / 'cache'
    cache.mkdir()
    (cache / 'data').symlink_to(BASE / 'setup/cache/data', target_is_directory=True)
    subprocess.run(['cp', '-a', '--reflink=auto', str(BASE / 'setup/cache/corepack'), str(cache / 'corepack')], check=True)
shutil.copy2(BASE / 'controller/upstream-production.patch', home / 'fix_grade.patch')
env_values = {
    'RUSTUP_HOME': str(BASE / 'toolchain/rustup'), 'CARGO_HOME': str(home / 'cache/cargo'),
    'CARGO_BUILD_JOBS': '4', 'COREPACK_HOME': str(home / 'cache/corepack'),
    'XDG_CACHE_HOME': str(home / 'cache'), 'XDG_DATA_HOME': str(home / 'cache/data'),
    'XDG_STATE_HOME': str(BASE / 'toolchain/state'),
    'npm_config_cache': str(home / 'cache/npm'), 'pnpm_config_verify_deps_before_run': 'false',
}
os.environ.update(env_values)
os.environ['PATH'] = str(BASE / 'toolchain/cargo/bin') + ':' + os.environ['PATH']
import shlex
prefix = 'umask 022; export PATH=' + shlex.quote(str(BASE / 'toolchain/cargo/bin')) + ':$PATH; '
original_sh = grade.sh
grade.sh = lambda command, cwd, timeout: original_sh(prefix + command, cwd, timeout)
grade.BUILD[case['id']] = 'corepack pnpm exec tsgo --build --force pnpm11/bins/cmd-shim'
grade.TIMEOUT[case['id']] = 180
plan = json.loads((BASE / 'plan.json').read_text())
for pair in plan['pairs']:
    for run in pair['runs']:
        if len(sys.argv) > 1 and run['id'] not in sys.argv[1:]:
            continue
        controller = Path(run['controller'])
        if not (controller / 'result.json').exists():
            continue
        out = controller / 'replay'
        out.mkdir(exist_ok=True)
        for variant, filename in [('full', 'result.json'), ('non-production', 'non-production-result.json')]:
            result = json.loads((controller / filename).read_text())
            label = run['id'] + '__' + variant
            if (out / f'{label}.json').exists():
                continue
            if not result['run_command']:
                record = {'label': label, 'verdict': 'no_reproduction_artifact'}
            else:
                record = grade.grade(case, label, result, out)
            (out / f'{label}.json').write_text(json.dumps(record, indent=2) + '\n')
            print(json.dumps(record), flush=True)
            if variant == 'full' and result['patch'] == json.loads((controller / 'non-production-result.json').read_text())['patch']:
                # Same patch means the projection is identical: no redundant replay.
                identical = dict(record, projection_identical_to_full=True)
                (out / f'{run["id"]}__non-production.json').write_text(json.dumps(identical, indent=2) + '\n')
