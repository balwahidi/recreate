import datetime
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
now = datetime.datetime.now(datetime.timezone.utc)
plan = json.loads((BASE / 'plan.json').read_text())
for pair in plan['pairs']:
    for run in pair['runs']:
        path = Path(run['controller']) / 'status.json'
        if not path.exists():
            continue
        s = json.loads(path.read_text())
        if s['state'] != 'running':
            continue
        seconds = (now - datetime.datetime.fromisoformat(s['started_at'])).total_seconds()
        trace = Path(run['workspace']) / '.telemetry/commands.jsonl'
        events = [json.loads(l) for l in trace.read_text().splitlines()] if trace.exists() else []
        last = events[-1] if events else {}
        print(json.dumps({'agent':s['agent'], 'run_id':run['id'], 'case':pair['case'], 'arm':run['arm'], 'seconds':round(seconds,1), 'limit':s['time_limit_seconds'], 'over_limit':seconds >= s['time_limit_seconds'], 'events':len(events), 'last_event':last.get('event'), 'last_at':last.get('at'), 'artifact_saved':(Path(run['workspace']) / 'agent-result.json').exists()}))
