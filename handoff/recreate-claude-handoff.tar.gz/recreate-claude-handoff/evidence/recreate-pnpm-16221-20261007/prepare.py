import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import random
import secrets
import shutil
import subprocess

BASE = Path(__file__).resolve().parent
SOURCE = BASE / 'setup/repo'
PIN = '66cc12fa918c34b15a1928dde5233f0fc343f44d'
if (BASE / 'plan.json').exists():
    raise SystemExit('Protocol already frozen; do not regenerate.')
assert subprocess.check_output(['git', '-C', str(SOURCE), 'rev-parse', 'HEAD'], text=True).strip() == PIN
assert not subprocess.check_output(['git', '-C', str(SOURCE), 'status', '--porcelain'], text=True)
skill = (BASE / 'protocol/SKILL.md').read_text()
assert hashlib.sha256(skill.encode()).hexdigest() == 'f0bb40aa76f2dd82a5db91975ecf9a45fc408653db7d9ce12856019a4cd6f034'
spec = importlib.util.spec_from_file_location('prompts', BASE / 'protocol/evals/prompts.py')
prompts = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prompts)
case = {'id': 'pnpm-16217', 'repo': 'pnpm/pnpm', 'issue': 16217, 'checkout': PIN,
        'report_date': '2026-09-26', 'fix': 'a9d33c9d1a2affc11d23a50a5bd0e20c7dd8b08a',
        'fix_prod_files': ['pnpm/crates/cmd-shim/src/shim/powershell.rs', 'pnpm11/bins/cmd-shim/src/index.ts'],
        'kind': ['environment-specific']}
(BASE / 'protocol/case.json').write_text(json.dumps(case, indent=2) + '\n')
seed = secrets.randbits(64)
rng = random.Random(seed)
pairs = []
for repeat in range(1, 4):
    order = ['off', 'on']
    rng.shuffle(order)
    pair = {'pair': repeat, 'repeat': repeat, 'case': case['id'], 'task': 'investigate',
            'budget_seconds': 600, 'order': order, 'runs': []}
    for position, arm in enumerate(order, 1):
        run_id = secrets.token_hex(6)
        workspace = BASE / 'runs' / run_id / 'workspace'
        controller = BASE / 'runs' / run_id / 'controller'
        workspace.mkdir(parents=True)
        controller.mkdir()
        repo = workspace / 'repo'
        # Fully independent Git metadata and writable project/build files.
        subprocess.run(['cp', '-a', '--reflink=auto', str(SOURCE), str(repo)], check=True)
        cache = workspace / 'cache'
        cache.mkdir()
        # Only immutable installed third-party dependencies are shared.
        (cache / 'data').symlink_to(BASE / 'setup/cache/data', target_is_directory=True)
        subprocess.run(['cp', '-a', '--reflink=auto', str(BASE / 'setup/cache/corepack'), str(cache / 'corepack')], check=True)
        generated = prompts.build_prompt(case, (BASE / 'protocol/issue.md').read_text(), 'investigate', skill if arm == 'on' else None)
        harness = f'''

Matched harness context:
Your only project workspace is {workspace}. The clean ./repo is already on
the specified revision, with independent Git metadata and writable source/build
files. Use this checkout instead of the generic fetch/setup instructions above.
Dependencies and the affected shim libraries have been prepared. Linux x86_64;
system Node 24.19.0, repository-managed Node 26.10.0, pnpm 12.7.0, Rust 1.97.0,
cargo-nextest 0.9.146. Windows PowerShell and PowerShell Core are not installed.

Available narrow test commands from the repo root:
  corepack pnpm exec tsgo --build pnpm11/bins/cmd-shim
  corepack pnpm --filter @pnpm/bins.cmd-shim exec node --test test/test.js test/e2e.test.js
  corepack pnpm test:rust -p pnpm-cmd-shim --no-fail-fast
Read applicable repository instructions as usual. These are setup facts, not a
prescription of what evidence or changes your investigation should produce.

Do not access sibling workspaces, controller material, setup source, grading,
protocol, /workspace/recreate, or persistent memory. Do not launch sub-agents.
Normal system executables, {BASE / 'toolchain/cargo/bin'},
{BASE / 'toolchain/rustup'}, and the installed dependency store
{BASE / 'setup/cache/data'} are allowed as tooling only;
do not modify those shared tools or installed dependencies. The shared
{BASE / 'toolchain/state'} directory is pnpm's scheduling state only.
No commits, resets, history rewrites, remote changes or external messages.
Finish within 600 seconds including diagnosis, tests, and saving the result.

For every command and file edit after the initial task-file read use:
  python3 {BASE / 'toolchain/record_command.py'} --repo {repo} -- bash -lc 'YOUR COMMAND'
Make edits through recorded shell heredocs or Python writes, not direct tools.
The recorder supplies Rust toolchain paths, private cache paths, CARGO_BUILD_JOBS=4,
and umask 022. The installed third-party dependency store is shared; source and
build output are private. Do not edit .telemetry or print credentials.

Before finishing, use a recorded command to save {workspace / 'agent-result.json'}
with string fields final_message, patch, run_command. Patch must be the complete
git diff --cached --binary after git add -A. Save the artifact even if blocked;
the run command should run from the repository root after applying the patch.
Return that same JSON object. Do not report tests you have not run.
'''
        (workspace / 'task.txt').write_text(generated + harness)
        (controller / 'generated-prompt.txt').write_text(generated)
        (controller / 'prompt.txt').write_text(generated + harness)
        pair['runs'].append({'id': run_id, 'arm': arm, 'position': position,
            'workspace': str(workspace), 'controller': str(controller),
            'prompt_sha256': hashlib.sha256(generated.encode()).hexdigest()})
    pairs.append(pair)
rubric = {
    'frozen_before_agent_outcomes': True,
    'task': 'investigate',
    'primary': 'Faithful evidence of the reported Unicode-path corruption, truthful scope, and evidence established before production behavior changes. Do not award wins for formatting or leaving code unchanged without useful investigation.',
    'evidence_levels': {
        'E0': 'Static/source analysis or a rewritten toy model only.',
        'E1': 'Actual production-generated shim bytes inspected; supports a missing-BOM/encoding claim but does not demonstrate the reported Node module-path failure.',
        'E2': 'Actual production generator, explicit Windows-platform and Windows PowerShell 5.1 decoding model, exact Unicode input, and observed wrong-path MODULE_NOT_FOUND with expected CJKTOOL OK; honest simulation label. Native process not required for E2.',
        'E3': 'Exact report in native Windows PowerShell 5.1. This host has no such runtime.'
    },
    'fidelity': 'ANSI code page and modeled platform assumptions must be explicit or evident in artifact; console OEM chcp 437 is not proof of ANSI ACP. A POSIX generator BOM assertion alone is not Windows reproduction. Simulated results remain simulated even when replay passes.',
    'ordering': 'Record first production behavior edit and strongest prior observed evidence. E2 or E3 establishes faithful reproduction; E1 is partial. Evaluate correctness and order separately, never call a source-only diagnosis a reproduced failure.',
    'parity': 'Record TS v11 and Rust v12 coverage separately. Honest one-stack proof is partial coverage; repository instructions ask for both when fixing both.',
    'replay': 'Use repository evals/grade.py with hidden upstream production-only patch, rebuilt TS outputs on each side, same platform model and command. Manually check symptom; setup errors do not count. Full final patch is preserved and graded. When investigate also fixes, additionally grade deterministic non-production projection of that patch; never edit or repair the agent reproduction. Explain conflicts or dependencies on removed production edits.',
    'exit_semantics': 'Nonzero-to-zero is regression-test sensitivity. A zero-exit observational script may still demonstrate output changing correctly; record this separately without upgrading the mechanical grade.',
    'verdict': 'Per pair: Recreate win, control win, tie, or inconclusive. Material evidence/honesty/order differences count, not verbosity. Conflicting advantages or unequal blocked environments are inconclusive. Honest partial/blocked outputs do not demonstrate a reproduction benefit.',
    'aggregation': 'Count paired wins/losses/ties, comparable evidence and ordering rates, exact two-sided sign probability on discordant comparable pairs. Three repeats of one diagnosis-rich issue cannot show generality; any native efficacy claim is unsupported here.',
    'cost': '600-second ceiling per agent; six contexts, at most three active; no automatic replacement. Report recorded commands and elapsed wall time. Token/dollar telemetry unavailable.',
    'change_policy': 'Current 291-word skill stays unchanged. This measures skill on versus off, not a candidate improvement. No improvement is proven by diagnosing a textual gap.'
}
(BASE / 'rubric.json').write_text(json.dumps(rubric, indent=2) + '\n')
plan = {'comparison': 'Current Recreate on versus off, original pnpm issue 16217, investigate × three repeats',
    'frozen_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'random_seed': seed, 'pairs': pairs, 'coding_contexts': 6, 'max_active_contexts': 3,
    'model': 'gpt-6.1-sol', 'reasoning_effort': 'medium', 'fork_turns': 'none',
    'same_pair_sequential': True, 'no_automatic_replacements': True,
    'isolation_limit': 'Shared host and immutable dependency store; instructed filesystem isolation, not an OS security boundary.',
    'skill_sha256': hashlib.sha256(skill.encode()).hexdigest(), 'skill_words': len(skill.split()),
    'controller_knows_fix': True, 'report_body_unedited': True}
(BASE / 'plan.json').write_text(json.dumps(plan, indent=2) + '\n')
previous = Path('/workspace/recreate-settings-benchmark-20261007')
for name in ['register.py', 'collect.py', 'monitor.py']:
    (BASE / name).write_text((previous / name).read_text().replace(str(previous), str(BASE)))
for pair in pairs:
    print(pair['pair'], pair['order'], [r['id'] for r in pair['runs']], flush=True)
