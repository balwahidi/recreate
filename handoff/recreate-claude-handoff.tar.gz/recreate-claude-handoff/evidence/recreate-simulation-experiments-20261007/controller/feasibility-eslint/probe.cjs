// Controller-only portability check; not given to evaluated agents.
const fs=require('node:fs'); const path=require('node:path');
const {ESLint}=require('./repo/lib/api.js');
(async()=>{const root=fs.mkdtempSync(path.join(__dirname,'files-'));try{
 const results=Array.from({length:1000},(_,i)=>({filePath:path.join(root,i+'.js'),output:'const x=1;\n'}));
 try{await ESLint.outputFixes(results);const fixed=results.filter(r=>fs.readFileSync(r.filePath,'utf8')===r.output).length;console.log(JSON.stringify({fixed,total:results.length,scope:'Native Linux descriptors capped at 128; production outputFixes path, not native Windows'}));if(fixed!==results.length)process.exitCode=1;}
 catch(error){console.log(JSON.stringify({code:error.code,message:error.message,scope:'Native Linux descriptor exhaustion in outputFixes'}));process.exitCode=1;}
 finally{await new Promise(r=>setTimeout(r,300));}
}finally{fs.rmSync(root,{recursive:true,force:true});}})();
