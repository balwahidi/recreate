// Controller-only feasibility check. Never shown to evaluated agents.
// Models the generator's Windows branch and legacy decoding, not Windows itself.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
const nativePlatform = process.platform;
const modeledPlatform = process.argv[2] || 'win32';
const modeledDecoder = process.argv[3] || 'legacy';
Object.defineProperty(process, 'platform', { value: modeledPlatform });
const { cmdShim } = await import('./repo/pnpm11/bins/cmd-shim/lib/index.js');
Object.defineProperty(process, 'platform', { value: nativePlatform });
const root = fs.mkdtempSync(path.resolve('controller/feasibility/fixture-'));
try {
  const target = path.join(root, 'proj/node_modules/cjk-tool/工具/cli.js');
  const shim = path.join(root, 'proj/node_modules/.bin/cjktool');
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.writeFileSync(target, '#!/usr/bin/env node\nconsole.log("CJKTOOL OK")\n');
  await cmdShim(target, shim, { createCmdFile: false, createPwshFile: true });
  const bytes = fs.readFileSync(shim + '.ps1');
  const hasBom = bytes.subarray(0,3).equals(Buffer.from([239,187,191]));
  const decoded = hasBom ? bytes.subarray(3).toString('utf8') : modeledDecoder === 'legacy' ? new TextDecoder('windows-1252').decode(bytes) : bytes.toString('utf8');
  const match = decoded.match(/"\$basedir\/([^"\r\n]*cli\.js)"/);
  assert.ok(match);
  const invocation = path.resolve(path.dirname(shim), match[1]);
  const actual = spawnSync(process.execPath, [invocation], { encoding: 'utf8' });
  console.log(JSON.stringify({ scope: 'Controller component diagnostic, not native Windows or PowerShell', nativePlatform, modeledPlatform, modeledDecoder, hasBom, invocation, status: actual.status, stdout: actual.stdout, stderr: actual.stderr }));
  assert.equal(actual.status, 0);
  assert.equal(actual.stdout.trim(), 'CJKTOOL OK');
} finally { fs.rmSync(root, { recursive: true, force: true }); }
