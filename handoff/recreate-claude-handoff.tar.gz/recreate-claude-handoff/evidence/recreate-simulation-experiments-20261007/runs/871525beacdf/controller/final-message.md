**Status: Reproduced (simulated Linux descriptor exhaustion).**

Running the real `eslint ./ --fix` on 9,000 generated files with a 256-descriptor limit failed in `writeFile → Promise.all → ESLint.outputFixes` in **3/3 trials** on the supplied revision. Only 238 files were fixed each time. ESLint 9.28.0 also failed in **1/1 trial**. With the normal 16,384-descriptor limit, both versions fixed all files in one control trial each.

Run: `node repro/emfile-fix.cjs` (exit 1 indicates the matching failure). The script and evidence are in `repro/`. Each trial has a 45-second timeout and uses `UV_THREADPOOL_SIZE=4`; ESLint starts all 9,000 writes together.

Likely cause: `outputFixes` writes every result concurrently without retrying descriptor exhaustion. Processing files in sequential small batches is a practical workaround; no CLI setting here limits those writes.

Existing `outputFixes` tests: **6 passing**. No production code changed. Native Windows and Node 22.11.0 were not tested.
