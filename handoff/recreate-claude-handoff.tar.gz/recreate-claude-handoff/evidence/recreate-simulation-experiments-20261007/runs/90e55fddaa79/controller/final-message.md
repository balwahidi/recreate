Status: Reproduced (simulated Windows PowerShell 5.1 ANSI decoding).

Both current v11 and v12 production shim generators emitted BOM-less UTF-8. Decoding their generated target arguments as Windows-1252 made 工具 become å·¥å…·; Node failed with MODULE_NOT_FOUND and exit 1. Expected: CJKTOOL OK. UTF-8 and BOM-prefixed controls printed it successfully. The smallest tested trigger is the reported non-ASCII bin path plus legacy decoding.

Run from the repository root: corepack pnpm exec tsgo --build pnpm11/bins/cmd-shim && node repro/ps1-encoding/reproduce.mjs

The command intentionally exits 1 for the reported failure. Artifacts and limits are documented in repro/ps1-encoding/README.md; generated files remain under its ignored .work directory.

The exact package fixture installed with pnpm 12.7.0 and its Linux sh shim worked. Native PowerShell 5.1/7 execution remains untested; Windows-1252 is assumed from the reported mojibake, not console code page 437. Node here is 24.19.0. Existing tests passed: 80 TypeScript and 170 Rust; Windows-specific checks were skipped. No production code was changed.
