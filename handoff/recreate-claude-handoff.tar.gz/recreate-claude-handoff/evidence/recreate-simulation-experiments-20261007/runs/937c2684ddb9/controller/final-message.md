**Status: Reproduced (simulated Windows PowerShell 5.1 ANSI decoding).**

Both current TypeScript and Rust generators emit BOM-less UTF-8 PowerShell shims. Decoding the generated target as Windows-1252 changes `工具` to `å·¥å…·`; invoking Node with that target fails with `MODULE_NOT_FOUND`, exit 1. Expected: `CJKTOOL OK`. UTF-8 and simulated BOM-aware decoding controls both print the expected output.

Trigger: a non-ASCII bin path plus ANSI decoding of a BOM-less `.ps1`. Console CP437 is distinct from the ANSI code page; Windows-1252 was selected to match the reported corruption.

Run from the repo root:
```sh
corepack pnpm exec tsgo --build pnpm11/bins/cmd-shim && node pnpm11/bins/cmd-shim/test/repro/powershell51.mjs --rust
```
The reproduction exits 1 on the reported failure. Artifacts: the reproduction script and README under `pnpm11/bins/cmd-shim/test/repro/`, plus `pnpm/crates/cmd-shim/examples/repro_pwsh51.rs`.

The exact package fixture installs successfully on Linux; Windows-only shim generation and ANSI decoding are simulated. Native Windows PowerShell 5.1 was unavailable. Node was 24.19.0, versus the reported 24.16.0. Existing checks: 80 TypeScript tests passed; 170 Rust tests passed, 1 skipped. No production code was changed.
