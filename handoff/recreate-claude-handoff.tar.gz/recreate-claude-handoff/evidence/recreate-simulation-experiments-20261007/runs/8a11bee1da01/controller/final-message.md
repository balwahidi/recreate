Status: Reproduced (simulated Windows PowerShell 5.1 decoding with ANSI Windows-1252).

Both current TypeScript and Rust shims lack a UTF-8 BOM. Decoding their actual bytes as Windows-1252 turns 工具 into å·¥å…·; real Node then exits 1 with MODULE_NOT_FOUND instead of printing CJKTOOL OK. Adding a BOM in memory restores exit 0 and the expected output for both. The exact fixture installs with pnpm 12.7.0, and its installed sh shim succeeds.

Run: corepack pnpm exec tsgo --build pnpm11/bins/cmd-shim && node scripts/repro-powershell-encoding/run.mjs

The command intentionally fails the reported expected-behavior assertion. Reproduction fixtures, runner, Rust generator example, and limitations are in scripts/repro-powershell-encoding/ and pnpm/crates/cmd-shim/examples/reproduce_powershell_encoding.rs. Native Windows/PowerShell were unavailable; Node was 24.19.0. Console code page 437 does not specify the ANSI code page. No production code was changed.
