Status: Reproduced (simulated descriptor exhaustion on Linux).

On ESLint 9.30.1 with Node 24.19.0, eslint ./ --fix throws EMFILE in outputFixes under a 256-descriptor limit: 3/3 trials with 9,000 files and 4/4 with 256 files failed, leaving only 238 files fixed. The unrestricted 9,000-file control passed. Windows and the reported versions were not tested.

Run: bash -c 'ulimit -n 256; node repro/emfile-fix.cjs 256' (expected exit 2). Artifacts: repro/emfile-fix.cjs and repro/README.md.

outputFixes starts every write concurrently. A portable workaround is to await ESLint.outputFixes([result]) for each lint result; this fixed 512/512 files under the same limit. The README includes the wrapper. Existing outputFixes tests: 6 passing. No production code was changed.
