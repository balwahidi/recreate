**Status: Reproduced (simulated descriptor scarcity).**

Running the real `eslint ./ --fix` on 9,000 files with 108,000 fixable semicolon issues should fix every file. With the child process's hard and soft open-file limits set to 256, it instead exits 2 with EMFILE from `writeFile → Promise.all → ESLint.outputFixes`. Only 238 files were fully fixed.

This matched in **3/3 trials on the supplied revision and 3/3 on ESLint 9.28.0**, with one CLI process at a time and a 90-second timeout per trial. Both versions fixed all files at the host's normal limit. This Linux/Node 24 simulation exercises the reported production path; the exact Windows/Node 22 environment was not tested.

Run from the repo root:

```sh
python3 tools/repro-emfile.py --limit 256 --trials 3
```

Artifacts: `tools/repro-emfile.py` and `tools/repro-emfile.md`. Existing outputFixes tests: **6 passing**. No production code changed.

Likely cause: outputFixes starts all writes concurrently without limiting open files. A cross-platform workaround is to fix smaller file groups sequentially, or await outputFixes for each small slice through the Node API; that workaround was not separately tested.
