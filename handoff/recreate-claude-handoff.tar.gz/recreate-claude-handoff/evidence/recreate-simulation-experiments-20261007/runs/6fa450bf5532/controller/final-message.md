**Status: Reproduced (simulated file descriptor exhaustion on Linux).**

The real `eslint ./ --fix` CLI, given 9,000 fixable files and a 512-file descriptor limit, throws the reported EMFILE stack in `writeFile → Promise.all → ESLint.outputFixes`, leaving only 494 files fully fixed. This matched in 6/6 trials on the supplied revision and 3/3 on published ESLint 9.28.0. Both versions fixed all files with the ordinary limit.

Run: `node repro/emfile.cjs`. Artifacts: `repro/emfile.cjs`, `repro/README.md`, and `repro/batched-fix.cjs`.

The cause appears to be unbounded concurrent output writes. The included API workaround writes fixes in sequential batches of 100; `node repro/emfile.cjs --batched` fixed all 9,000 files under the same limit. Its Node implementation can be used on Windows and Linux; Windows execution was not tested.

The reporter’s Windows/Node 22 environment and exact input were not available; the 9.28.0 check used host Node and preinstalled dependencies. Existing outputFixes tests passed (6). No production code was changed.
