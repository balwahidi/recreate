**Status: Reproduced (simulated Windows PowerShell 5.1 ANSI decoding).**

Both current v11 and v12 production shim generators emit UTF-8 without a BOM. With simulated ANSI CP1252 loading, the report's fixture reaches Node with `å·¥å…·/cli.js`, producing `MODULE_NOT_FOUND` and exit 1 (2/2 implementations). Expected: `CJKTOOL OK`. UTF-8 and BOM-prefixed controls print that message and exit 0.

Run from the repo root: `node repro/ps1-encoding/reproduce.mjs`. A matching reproduction exits 1 and saves shims and results under `repro/ps1-encoding/artifacts/`.

This runs the actual generators and Node invocation, but simulates script decoding; neither PowerShell 5.1 nor PowerShell 7 ran. CP1252 matches the reported mojibake; console CP437 does not establish the ANSI code page. Host Node was 24.19.0, rather than the reported 24.16.0.

Validation: 80 TypeScript tests passed; 170 Rust tests passed, 1 skipped. Production code was unchanged; only reproduction helpers were added.
