**Status: Reproduced (simulated Windows PowerShell 5.1 / Windows-1252).**

Both current TypeScript and Rust generators emit BOM-less UTF-8. With the report’s installed package fixture, simulated ANSI decoding turns `工具` into `å·¥å…·`; real Node exits 1 with `MODULE_NOT_FOUND`. UTF-8 and BOM decoding controls print `CJKTOOL OK`. Both generators reproduced twice (4/4 simulated failures).

Run: `corepack pnpm exec tsgo --build pnpm11/bins/cmd-shim && node repro/powershell-encoding/reproduce.mjs` (expected exit 1). Reproduction helpers and limitations are in `repro/powershell-encoding/README.md`; the harness prints its fixture directory.

The TypeScript shim suite passed 80 tests; Windows suites were skipped. Native Windows/PowerShell execution remains unverified on this Linux host; Node was 24.19.0 rather than 24.16.0. No production code was changed.
