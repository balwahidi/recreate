**Status: Reproduced (simulated Linux descriptor limit).**

With 9,000 files and a 1,024-descriptor limit, `eslint ./ --fix` fails with the reported `EMFILE → writeFile → ESLint.outputFixes` stack in 3/3 trials on both the supplied revision and ESLint 9.28.0. Only 1,006 files are fixed per trial; all 9,000 should be fixed. With the normal 16,384 limit, both versions pass one control trial.

Run: `node repro/emfile.cjs --simulate`. The fixture and findings are in `repro/`. This uses synthetic input on Linux/Node 24, so it does not establish the exact Windows/Node 22 behavior.

Likely cause: `outputFixes` starts all file writes concurrently. A workaround is to run `--fix` sequentially on smaller file batches. Production code is unchanged; the existing outputFixes tests pass (6 tests).
