"""Frozen repository grader with environment adapters for the two selected cases."""
import importlib.util
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys

BASE = Path(__file__).resolve().parent
OLD = Path('/workspace/recreate-pnpm-16221-20261007')
spec = importlib.util.spec_from_file_location('grade', BASE / 'protocol/grade.py')
grade = importlib.util.module_from_spec(spec)
spec.loader.exec_module(grade)
grade.GRADE = BASE / 'controller/grade-work'
grade.SETUP.pop('eslint-19924', None)  # Exact installed dependency snapshot in both sides.
grade.BUILD['pnpm-16217'] = 'corepack pnpm exec tsgo --build --force pnpm11/bins/cmd-shim'
grade.TIMEOUT.update({'pnpm-16217':180, 'eslint-19924':120})
original_sh = grade.sh
prefix = 'umask 022; export PATH=' + shlex.quote(str(BASE / 'toolchain/cargo/bin')) + ':$PATH; '
grade.sh = lambda command, cwd, timeout: original_sh(prefix + command, cwd, timeout)
plan = json.loads((BASE / 'plan.json').read_text())
for pair in plan['pairs']:
    case = json.loads((BASE / 'protocol' / pair['case'] / 'case.json').read_text())
    for run in pair['runs']:
        if len(sys.argv) > 1 and run['id'] not in sys.argv[1:]:
            continue
        controller = Path(run['controller'])
        if not (controller / 'result.json').exists():
            continue
        home = grade.GRADE / pair['case']
        repo = home / 'repo'
        home.mkdir(parents=True, exist_ok=True)
        if not repo.exists():
            subprocess.run(['cp', '-a', '--reflink=auto', pair['source'], str(repo)], check=True)
            (home / 'cache').mkdir()
            if pair['case'] == 'pnpm-16217':
                (home / 'cache/data').symlink_to(OLD / 'setup/cache/data', target_is_directory=True)
                subprocess.run(['cp', '-a', '--reflink=auto', str(OLD / 'setup/cache/corepack'), str(home / 'cache/corepack')], check=True)
        patch = OLD / 'controller/upstream-production.patch' if pair['case'] == 'pnpm-16217' else BASE / 'controller/eslint-upstream-production.patch'
        shutil.copy2(patch, home / 'fix_grade.patch')
        os.environ.update({
            'RUSTUP_HOME':str(BASE / 'toolchain/rustup'), 'CARGO_HOME':str(home / 'cache/cargo'),
            'CARGO_BUILD_JOBS':'4', 'COREPACK_HOME':str(home / 'cache/corepack'),
            'XDG_CACHE_HOME':str(home / 'cache'), 'XDG_DATA_HOME':str(home / 'cache/data'),
            'XDG_STATE_HOME':str(BASE / 'toolchain/state'), 'npm_config_cache':str(home / 'cache/npm'),
            'pnpm_config_verify_deps_before_run':'false', 'CYPRESS_INSTALL_BINARY':'0',
        })
        os.environ['PATH'] = str(BASE / 'toolchain/cargo/bin') + ':' + os.environ['PATH']
        out = controller / 'replay'
        out.mkdir(exist_ok=True)
        for variant, filename in [('full','result.json'),('non-production','non-production-result.json')]:
            result = json.loads((controller / filename).read_text())
            label = run['id'] + '__' + variant
            if (out / (label + '.json')).exists():
                continue
            record = {'label':label, 'verdict':'no_reproduction_artifact'} if not result['run_command'] else grade.grade(case,label,result,out)
            (out / (label + '.json')).write_text(json.dumps(record,indent=2)+'\n')
            print(json.dumps(record),flush=True)
            if variant == 'full' and result['patch'] == json.loads((controller / 'non-production-result.json').read_text())['patch']:
                identical = dict(record, projection_identical_to_full=True)
                (out / (run['id'] + '__non-production.json')).write_text(json.dumps(identical,indent=2)+'\n')
