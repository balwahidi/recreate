"""Check frozen prompts and preserved artifacts; does not adjudicate efficacy."""
import hashlib
import importlib.util
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
plan = json.loads((BASE / 'plan.json').read_text())
spec = importlib.util.spec_from_file_location('prompts', BASE / 'protocol/prompts.py')
prompts = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prompts)
checks = []
for pair in plan['pairs']:
    generated_by_arm = {}
    normalized_harness = []
    for run in pair['runs']:
        controller, workspace = Path(run['controller']), Path(run['workspace'])
        case = json.loads((BASE / 'protocol' / pair['case'] / 'case.json').read_text())
        skill = (BASE / 'protocol' / (run['arm'] + '-SKILL.md')).read_text()
        generated = prompts.build_prompt(case, (BASE / 'protocol' / pair['case'] / 'issue.md').read_text(), pair['task'], skill)
        assert generated == (controller / 'generated-prompt.txt').read_text()
        assert hashlib.sha256(generated.encode()).hexdigest() == run['prompt_sha256']
        full = (controller / 'prompt.txt').read_text()
        assert full == (workspace / 'task.txt').read_text()
        assert full.startswith(generated)
        normalized_harness.append(full[len(generated):].replace(str(workspace), '<workspace>'))
        generated_by_arm[run['arm']] = generated.replace(skill.strip(), '<skill>')
        status = json.loads((controller / 'status.json').read_text())
        if status['state'] == 'agent_error':
            assert (controller / 'agent-error.txt').exists()
            assert (controller / 'actual-final.patch').exists()
            assert not (workspace / 'agent-result.json').exists()
            checks.append({'run_id':run['id'], 'prompt_and_harness_verified':True,
                           'agent_error_preserved':True, 'partial_tree_preserved':True})
            continue
        assert status['state'] == 'completed'
        assert status['agent_patch_matches_actual_tree']
        result = json.loads((controller / 'result.json').read_text())
        assert result == json.loads((workspace / 'agent-result.json').read_text())
        assert result['patch'] == (controller / 'actual-final.patch').read_text()
        assert result['patch'] == (controller / 'agent.patch').read_text()
        assert (controller / 'replay' / (run['id'] + '__full.json')).exists()
        checks.append({'run_id':run['id'], 'prompt_and_harness_verified':True,
                       'result_matches_saved_tree':True, 'replay_preserved':True})
    assert len(set(generated_by_arm.values())) == 1
    assert len(set(normalized_harness)) == 1

repo_skill = Path('/workspace/recreate/SKILL.md').read_bytes()
skill_sha = hashlib.sha256(repo_skill).hexdigest()
assert skill_sha == plan['skills']['current']['sha256']
for filename in ['prompts.py', 'grade.py']:
    assert (BASE / 'protocol' / filename).read_bytes() == (Path('/workspace/recreate/evals') / filename).read_bytes()
assert len(checks) == 12
result = {'contexts_verified':len(checks), 'completed_results_verified':sum('result_matches_saved_tree' in c for c in checks),
          'agent_errors_preserved':sum('agent_error_preserved' in c for c in checks), 'repository_skill_sha256':skill_sha,
          'repository_skill_unchanged':True, 'checks':checks}
(BASE / 'verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k:v for k,v in result.items() if k != 'checks'}))
