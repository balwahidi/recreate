This experiment used the existing cloud environment and isolated copies of two pinned repositories. No service, startup command, or permanent configuration change is needed for Recreate itself: its evaluation scripts use the Python standard library.

Host tools: Linux x86_64, Node 24.19.0, npm 11.9.0, Python 3, Git. pnpm uses pnpm 12.7.0 and repository-managed Node 26.10.0; Rust 1.97.0 and cargo-nextest 0.9.146 are installed under the experiment toolchain. Native Windows PowerShell and PowerShell Core are unavailable.

pnpm is pinned to `66cc12fa918c34b15a1928dde5233f0fc343f44d`, reusing the previously prepared source/dependency seed at `/workspace/recreate-pnpm-16221-20261007/setup/repo`. Each coding run has separate source, Git metadata, and build output. The shared dependency store is tooling only. Narrow validation commands:

```sh
corepack pnpm exec tsgo --build pnpm11/bins/cmd-shim
corepack pnpm --filter @pnpm/bins.cmd-shim exec node --test test/test.js test/e2e.test.js
corepack pnpm test:rust -p pnpm-cmd-shim --no-fail-fast
```

Baseline checks were 80 TypeScript tests and 170 Rust tests passing, with one Rust test skipped. Use the supplied recorder to obtain the same Rust, Corepack, private-cache, umask, and pnpm scheduling environment. `pnpm_config_verify_deps_before_run=false` prevents relocated dependency metadata from triggering automatic reinstalls.

ESLint is pinned to `35cf44c22e36b1554486e7a75c870e86c10b83f8`. The seed was installed once, then copied to both arms with identical installed dependencies:

```sh
CYPRESS_INSTALL_BINARY=0 npm install --ignore-scripts --no-audit --no-fund --package-lock=false
node node_modules/mocha/bin/mocha.js tests/lib/eslint/eslint.js --grep outputFixes
```

ESLint baseline: six tests passing. This revision has no tracked lockfile; future dependency resolution may differ, so reuse the preserved seed to reproduce this exact experiment. `install.log` and `baseline.log` are under `setup/eslint-19924/`.

`copy-validation.json` records clean starting trees and successful import/targeted-test checks on all twelve independent copies before any coding run. No run required a setup pause. `cache-cleanup.json` records deletion of redundant generated caches from the earlier benchmark; its source, patches, results, and logs were preserved.

For audit, run `python3 verify.py` and `python3 metrics.py` from the experiment root. `replay.py` uses the unchanged repository grader with pinned tool/dependency setup adapters. Do not run two replay processes concurrently for the same case: grading deliberately reuses a controller-only checkout. Agent artifacts must remain unchanged.
