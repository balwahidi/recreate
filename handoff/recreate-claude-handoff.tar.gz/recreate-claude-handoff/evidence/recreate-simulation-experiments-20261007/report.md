**The proposed skill change did not earn adoption.** It produced no pnpm improvement, and the ESLint transfer case showed no improvement in faithful reproduction. Recreate's repository files were not changed by this experiment.

I attempted twelve fresh GPT-6.1 Sol contexts at medium effort: three paired `investigate` runs on pnpm issue 16217 (fixed by PR 16221), and three on ESLint issue 19924. Eleven contexts saved complete artifacts. One current-skill ESLint context was stopped by a platform cybersecurity-risk filter before its final result; that pair is inconclusive, with no replacement run. This is a follow-up comparison of **current skill versus candidate skill**, both enabled, not another on/off benchmark.

The candidate replaced exactly one rule. Current: “If you simulate a condition you can't match (such as another OS), call the result simulated.” Candidate: “Label simulations. They must exercise the reported environment's production path and matching failure; otherwise report partial evidence.” Word count changed from **291 to 292**. The text was frozen before reading the transfer issue; cases were selected from the skill's claims, not saved results. pnpm tests the known simulation gap; ESLint tests whether a stricter rule discourages useful Linux evidence for a Windows report. ESLint is a registry development case, not a formal untouched holdout.

Each pair used identical model, effort, task, tools, dependency seed, revision and budget: 480 seconds for pnpm, 300 for ESLint. Pair order was randomized before execution. Each context used an independent source checkout and inherited no parent conversation. All complete artifacts were saved within budget. The controller's feasibility probes and upstream fixes were hidden from evaluated agents. See the frozen [plan](plan.json), [rubric](rubric.json), [prompts](protocol/prompts.py), and [verification](verification.json).

Command exit codes below are **before → after the real upstream production-only fix**, using each agent's unchanged patch and command through the repository grader. Source/log review checks the reported symptom separately.

| Test, all `investigate` | Current skill | Candidate | Objective evidence | Frozen-primary verdict |
| --- | --- | --- | --- | --- |
| pnpm-16217, pair 1 | [1 → 1](runs/937c2684ddb9/controller/replay/937c2684ddb9__full.json) | [1 → 1](runs/84c573db070c/controller/replay/84c573db070c__full.json) | Both retain Linux generator state; Node `MODULE_NOT_FOUND` persists after fix. | Tie, both miss primary |
| pnpm-16217, pair 2 | [1 → 1](runs/8a11bee1da01/controller/replay/8a11bee1da01__full.json) | [1 → 1](runs/904163b46b12/controller/replay/904163b46b12__full.json) | Same platform mismatch and persistent wrong-path failure. | Tie, both miss primary |
| pnpm-16217, pair 3 | [1 → 1](runs/303ed57dde7a/controller/replay/303ed57dde7a__full.json) | [1 → 1](runs/90e55fddaa79/controller/replay/90e55fddaa79__full.json) | Same mismatch; current also asserts bug behavior and hardcodes failure. | Tie, both miss primary |
| eslint-19924, pair 4 | [0 → 1](runs/10304b9c0f82/controller/replay/10304b9c0f82__full.json) | [0 → 1](runs/41768decd51b/controller/replay/41768decd51b__full.json) | Both observe real CLI write-stage EMFILE; after fix both write 9,000/9,000 files in every replay trial. Both harnesses invert grader convention. | Tie, both miss primary |
| eslint-19924, pair 5 | [Platform interruption](runs/8deba87f9d49/controller/agent-error.txt) | [1 → 0](runs/871525beacdf/controller/replay/871525beacdf__full.json) | Candidate: matching failures 3/3 before, 0/3 after; all 9,000 files fixed. Current has partial logs but no final artifact. | Inconclusive; excluded |
| eslint-19924, pair 6 | [2 → 0](runs/7ab64eb1b6b0/controller/replay/7ab64eb1b6b0__full.json) | [0 → 1](runs/6fa450bf5532/controller/replay/6fa450bf5532__full.json) | Current's minimized command fixes 256/256 after fix. Candidate fixes 9,000/9,000, then fails an assertion demanding the bug. | Current win on command convention; symptom evidence ties |

Across comparable pairs, the frozen primary scores are **pnpm 0/3 versus 0/3**, and **ESLint current 1/2 versus candidate 0/2**. Pairwise: four ties, one current win limited to command convention, one inconclusive. There are no candidate wins. The unmatched candidate success is preserved but excluded from paired aggregates.

The substantive ESLint finding is stronger than its raw grade: **both arms produced faithful, fix-sensitive evidence in 2/2 comparable runs**. All five completed ESLint artifacts reach the real `eslint ./ --fix` write path under native Linux descriptor limits; the real fix resolves the symptom. Three of these five return success when detecting the bug and failure when it disappears. The shared prompt asks for a command demonstrating the bug but does not explicitly state the grader's exit convention. The grader labels these `fails_both` even though their exits are 0 → 1; the raw label must not be read as evidence that production remained broken. No artifact was repaired or rescored as a primary pass.

All eleven completed runs labeled their simulations and left production implementation unchanged. Thus **0/11 edited production before a faithful reproduction**, and no implementation fix needs to be removed to replay them. The interrupted context also has no recorded production edit. ESLint agents measured multiple matching trials and reported limits/concurrency; there was no blanket refusal to investigate on Linux. These are shared behaviors, not evidence that the candidate improved them.

The pnpm mechanism is the useful new diagnosis. All six agents call actual production generators, model Windows-1252 decoding, and cause real Node failures with the reported mojibake. That is useful partial evidence. But before the fix the generator produces the same relevant bytes on Linux and Windows, so checking the function and pre-fix symptom does not expose the missing Windows input. The legitimate upstream fix deliberately adds the BOM only on Windows, preserving POSIX shebang behavior.

A controller-only two-by-two probe isolates this distinction. It uses the TypeScript production generator, configures its platform input before module initialization, models decoding, and invokes real Node. This is not native PowerShell execution and is not credited to an agent or candidate.

| Modeled generator platform | Decoder | Before fix | After fix |
| --- | --- | --- | --- |
| Windows | Legacy Windows-1252 | Fail | Pass |
| Windows | UTF-8 | Pass | Pass |
| Linux | Legacy Windows-1252 | Fail | Fail |
| Linux | UTF-8 | Pass | Pass |

These [eight controller observations](controller/feasibility/component-matrix.json) demonstrate why the agent simulations miss the fix. They do not prove that any alternative wording will teach the distinction. A separate [ESLint feasibility control](controller/feasibility-eslint/results.json) also confirms the transfer task is achievable: actual `outputFixes` fails with EMFILE before the fix and writes 1,000/1,000 files afterward under the same descriptor limit.

Recorded effort for **complete pairs only**:

| Case | Current median seconds to saved artifact | Candidate median seconds | Current / candidate total recorded commands |
| --- | ---: | ---: | ---: |
| pnpm, 3 pairs | 247 | 280 | 31 / 42 |
| ESLint, 2 pairs | 198 | 241 | 16 / 20 |

The candidate was about 13% and 22% slower in these small samples. Timing includes agent reasoning and command execution through the artifact-saving command, excludes final-answer rendering and controller collection delay, and is affected by shared-host scheduling. This is not token or dollar cost. The paired candidate did not show an efficiency benefit. Full measurements are in [metrics.json](metrics.json).

**Recommendation: keep the current skill.** The frozen promotion rule required three pnpm primary improvements and no material transfer regression; the candidate achieved zero pnpm improvements. The first inexpensive adjustment to propose is to the common evaluation prompt: explicitly require nonzero exit for violated expected behavior and zero after it succeeds. The observed grading mismatch supports fixing that contract, but its effect on future agents still needs a prospective check.

The single best next skill experiment is to test a procedural environment rule on an unseen issue: have the agent locate where production reads the missing condition, set the model at that boundary before initialization, and verify its effective value. Keep the same expected-behavior assertion and a hidden real-fix replay. This may help where the abstract “production path” sentence failed; it is **untested and has not been installed**. The detailed [next experiment proposal](next-experiment.md) distinguishes this hypothesis from established evidence.

Limits: two issue families, one deliberately selected development failure, only five complete pairs, unblinded manual review, shared host/caches, and no native Windows execution. Randomization happened to put the candidate first in all ESLint pairs. The platform-filter interruption prevents the planned third transfer comparison. Already-fixed reports, exact-input substitution, and scheduling-sensitive flaky rates remain untested here. This experiment rejects one candidate under its frozen gate; it does not establish broad Recreate effectiveness or ineffectiveness.

All final messages, patches, commands, command traces and replay logs are under `runs/<id>/controller/`; partial work from the interrupted context is preserved separately. [Review decisions](review.json), [environment setup](setup/environment.md), and [verification](verification.json) are saved. The repository SKILL.md still has SHA-256 `f0bb40aa76f2dd82a5db91975ecf9a45fc408653db7d9ce12856019a4cd6f034`. No PR was created.
