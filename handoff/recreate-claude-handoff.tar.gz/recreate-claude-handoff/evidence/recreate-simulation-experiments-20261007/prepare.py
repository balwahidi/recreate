import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import random
import secrets
import subprocess

BASE = Path(__file__).resolve().parent
OLD = Path('/workspace/recreate-pnpm-16221-20261007')
assert not (BASE / 'plan.json').exists(), 'Protocol already frozen.'
skills = {arm: (BASE / 'protocol' / (arm + '-SKILL.md')).read_text() for arm in ['current', 'candidate']}
spec = importlib.util.spec_from_file_location('prompts', BASE / 'protocol/prompts.py')
prompts = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prompts)
conditions = [
    {'case': 'pnpm-16217', 'source': str(OLD / 'setup/repo'), 'budget_seconds': 480,
     'role': 'Development case that motivated the frozen single-rule candidate.'},
    {'case': 'eslint-19924', 'source': str(BASE / 'setup/eslint-19924/repo'), 'budget_seconds': 300,
     'role': 'Transfer and over-abstention check. Repository dev case; held out from this candidate wording, not claimed to be a previously untouched benchmark.'},
]
seed = secrets.randbits(64)
rng = random.Random(seed)
pairs = []
for condition in conditions:
    source = Path(condition['source'])
    case_dir = BASE / 'protocol' / condition['case']
    case = json.loads((case_dir / 'case.json').read_text())
    assert subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip() == case['checkout']
    assert not subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain'], text=True)
    for repeat in range(1, 4):
        order = ['current', 'candidate']
        rng.shuffle(order)
        pair = dict(condition, task='investigate', repeat=repeat, pair=len(pairs) + 1, order=order, runs=[])
        for position, arm in enumerate(order, 1):
            run_id = secrets.token_hex(6)
            workspace = BASE / 'runs' / run_id / 'workspace'
            controller = BASE / 'runs' / run_id / 'controller'
            workspace.mkdir(parents=True)
            controller.mkdir()
            repo = workspace / 'repo'
            subprocess.run(['cp', '-a', '--reflink=auto', str(source), str(repo)], check=True)
            cache = workspace / 'cache'
            cache.mkdir()
            if case['id'] == 'pnpm-16217':
                (cache / 'data').symlink_to(OLD / 'setup/cache/data', target_is_directory=True)
                subprocess.run(['cp', '-a', '--reflink=auto', str(OLD / 'setup/cache/corepack'), str(cache / 'corepack')], check=True)
                setup = '''System Node 24.19.0; repository-managed Node 26.10.0; pnpm 12.7.0;
Rust 1.97.0; cargo-nextest 0.9.146. Windows PowerShell and PowerShell Core are
not installed. Dependencies and shim-library build outputs are preinstalled.
Available narrow commands from the root:
  corepack pnpm exec tsgo --build pnpm11/bins/cmd-shim
  corepack pnpm --filter @pnpm/bins.cmd-shim exec node --test test/test.js test/e2e.test.js
  corepack pnpm test:rust -p pnpm-cmd-shim --no-fail-fast
'''
            else:
                setup = '''Node 24.19.0; npm 11.9.0. Dependencies are preinstalled from the
same seed in both arms. No build is required for the JavaScript implementation.
Available targeted test command from the root:
  node node_modules/mocha/bin/mocha.js tests/lib/eslint/eslint.js --grep outputFixes
'''
            generated = prompts.build_prompt(case, (case_dir / 'issue.md').read_text(), 'investigate', skills[arm])
            harness = f'''

Matched harness context:
Your only project workspace is {workspace}. Its clean ./repo is already at
the supplied revision, with independent writable source, Git metadata and build
output. Use it instead of the generic fetch/setup instructions above. Host:
Linux x86_64. Read applicable repository instructions as usual.
{setup}
These are neutral setup facts; decide how to investigate the report yourself.
Do not access sibling workspaces, controller material, setup source, grading,
protocol, /workspace/recreate, other benchmarks, or persistent memory. Do not
launch sub-agents. Normal system executables, {BASE / 'toolchain/cargo/bin'},
{BASE / 'toolchain/rustup'}, and the installed dependency store
{OLD / 'setup/cache/data'} are allowed as tooling only. Do not change shared
tools or installed third-party packages. The shared {BASE / 'toolchain/state'}
directory is only pnpm scheduling state. No commits, resets, history rewrites,
remote changes or external messages. Finish within {condition['budget_seconds']}
seconds, including investigation, tests and saving the result.

For every command and file edit after the initial task-file read use:
  python3 {BASE / 'toolchain/record_command.py'} --repo {repo} -- bash -lc 'YOUR COMMAND'
Make edits through recorded shell heredocs or Python writes, not direct tools.
The recorder provides Rust paths, private cache paths, CARGO_BUILD_JOBS=4,
umask 022, CYPRESS_INSTALL_BINARY=0 and pnpm_config_verify_deps_before_run=false
(the latter prevents relocated dependency metadata from triggering reinstalls).
Do not edit .telemetry or print credentials.

Before finishing, use a recorded command to save {workspace / 'agent-result.json'}
with string fields final_message, patch, run_command. Patch must be the complete
git diff --cached --binary after git add -A. Save it even if blocked. The run
command must work from the repo root after applying the patch. Return that same
JSON object. Do not report tests you have not run.
'''
            (workspace / 'task.txt').write_text(generated + harness)
            (controller / 'generated-prompt.txt').write_text(generated)
            (controller / 'prompt.txt').write_text(generated + harness)
            pair['runs'].append({'id':run_id, 'arm':arm, 'position':position, 'workspace':str(workspace),
                                'controller':str(controller), 'prompt_sha256':hashlib.sha256(generated.encode()).hexdigest()})
        pairs.append(pair)
rubric = {
    'frozen_before_outcomes': True,
    'comparison': 'Current 291-word Recreate versus frozen 292-word one-rule replacement; both skill-enabled. No off arm or additional wording changes.',
    'pnpm-16217': {
        'primary': 'Actual generator follows the modeled Windows production path; exact Unicode target reaches matching Node MODULE_NOT_FOUND in a clearly bounded PS5.1 decoding simulation or native Windows. Unmodified reproduction must fail before and pass after the upstream production-only fix.',
        'partial': 'Linux-generated shims plus CP1252 decoding can support a partial mechanism claim, but failing unchanged after the real fix is not primary success. Labels alone earn no win.',
        'secondary': 'Appropriate evidence limits; no production edit before faithful observation; useful artifacts rather than blanket abstention. Coverage of TS/Rust recorded separately.',
    },
    'eslint-19924': {
        'primary': 'Reported outputFixes writing path reaches EMFILE for many fix outputs, with expected files fixed. Same reproduction fails before and passes after upstream production-only fix. Low child-process descriptor limits or bounded, validated descriptor-exhaustion models are allowed with truthful scope.',
        'not_success': 'EMFILE during module loading or unrelated reads, a hardcoded throw, a permanently failing write mock, or an extra assertion that hides successful outputFixes is not the reported symptom.',
        'over_abstention': 'Do not require Windows when the same relevant production path can be observed on Linux. A candidate that refuses feasible useful evidence or loses valid replays regresses.',
    },
    'replay': 'Use frozen evals/grade.py. Preserve full result; additionally replay deterministic non-production projection if investigate changed implementation. Never repair or rewrite an agent reproduction. Validate reported symptom independently of exit status.',
    'verdict': 'Candidate win/current win/tie/inconclusive per pair. Valid replay and faithful path are primary; calibration/productivity/order are separately reported. A changed status label or refusal alone is not an efficacy win.',
    'decision': 'Recommend promotion only with three repeated primary improvements on pnpm and no material transfer regression. Otherwise retain current skill and report the failure or ambiguity. Do not edit the repository skill or make a PR in this experiment.',
    'scope': 'Six randomized pairs, twelve contexts, maximum three active; each pair sequential; no automatic replacements, extra cases or outcome-driven tuning.',
    'cost': 'Measure commands and elapsed time to saved artifact, report word count. No token/dollar telemetry. pnpm budget 480s, ESLint 300s, equal within every pair.',
    'limitations': 'One development issue and one transfer issue, small n, shared host, manual review unblinded. Transfer case is registry dev, not an untouched formal holdout. Dependency and compiler scheduling affect timings.',
}
(BASE / 'rubric.json').write_text(json.dumps(rubric,indent=2)+'\n')
plan = {'frozen_at':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'comparison':rubric['comparison'],
        'random_seed':seed, 'pairs':pairs, 'coding_contexts':12, 'max_active_contexts':3,
        'model':'gpt-6.1-sol', 'reasoning_effort':'medium', 'fork_turns':'none',
        'skills':json.loads((BASE / 'protocol/text-freeze.json').read_text())['variants'],
        'controller_feasibility_probe_hidden':True, 'no_repository_skill_changes':True,
        'isolation':'Fresh contexts and independent source/checkouts; shared host and installed tools, not an OS security boundary.'}
(BASE / 'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
for pair in pairs:
    print(pair['pair'], pair['case'], pair['order'], [r['id'] for r in pair['runs']],flush=True)
